import 'package:flutter/material.dart';

class mostrar_texto extends StatefulWidget {
  @override
  _mostrar_texto createState() => _mostrar_texto();
}

class _mostrar_texto extends State<mostrar_texto> {
  String _text = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Contador"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Mostrar Texto'),
            SizedBox(height: 16),
            TextField(
              onChanged: (text) {
                setState(() {
                  _text = text;
                });
              },
              decoration: InputDecoration(
                labelText: 'Ingrese un texto',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            Text(_text),
          ],
        ),
      ),
    );
  }
}
